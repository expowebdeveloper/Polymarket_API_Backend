from sqlalchemy import Column, Integer, String, Numeric, Boolean, DateTime, Text, UniqueConstraint
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)


class Position(Base):
    __tablename__ = "positions"

    id = Column(Integer, primary_key=True, index=True)
    proxy_wallet = Column(String(42), index=True, nullable=False)
    asset = Column(String, nullable=False, index=True)
    condition_id = Column(String(66), nullable=False, index=True)
    size = Column(Numeric(20, 8), nullable=False)
    avg_price = Column(Numeric(10, 6), nullable=False)
    initial_value = Column(Numeric(20, 8), nullable=False)
    current_value = Column(Numeric(20, 8), nullable=False, default=0)
    cash_pnl = Column(Numeric(20, 8), nullable=False)
    percent_pnl = Column(Numeric(10, 4), nullable=False)
    total_bought = Column(Numeric(20, 8), nullable=False)
    realized_pnl = Column(Numeric(20, 8), nullable=False, default=0)
    percent_realized_pnl = Column(Numeric(10, 4), nullable=False)
    cur_price = Column(Numeric(10, 6), nullable=False, default=0)
    redeemable = Column(Boolean, default=False)
    mergeable = Column(Boolean, default=False)
    title = Column(Text)
    slug = Column(String(255), index=True)
    icon = Column(Text)
    event_id = Column(String(50), index=True)
    event_slug = Column(String(255))
    outcome = Column(String(255))
    outcome_index = Column(Integer)
    opposite_outcome = Column(String(255))
    opposite_asset = Column(String)
    end_date = Column(String(50))
    negative_risk = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        UniqueConstraint('proxy_wallet', 'asset', 'condition_id', name='uq_position_wallet_asset_condition'),
    )


class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    token_id = Column(String, nullable=False, index=True)
    token_label = Column(String(10), nullable=False)  # "Yes" or "No"
    side = Column(String(10), nullable=False, index=True)  # "BUY" or "SELL"
    market_slug = Column(String(255), nullable=False, index=True)
    condition_id = Column(String(66), nullable=False, index=True)
    shares = Column(Numeric(30, 0), nullable=False)  # Large numbers for shares
    price = Column(Numeric(10, 8), nullable=False)
    tx_hash = Column(String(66), nullable=False, index=True)
    title = Column(Text)
    timestamp = Column(Integer, nullable=False, index=True)  # Unix timestamp
    order_hash = Column(String(66), nullable=False, unique=True, index=True)
    user = Column(String(42), nullable=False, index=True)  # Wallet address
    taker = Column(String(42), nullable=False, index=True)  # Taker wallet address
    shares_normalized = Column(Numeric(20, 8), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class UserPnL(Base):
    __tablename__ = "user_pnl"

    id = Column(Integer, primary_key=True, index=True)
    user_address = Column(String(42), nullable=False, index=True)  # Wallet address
    timestamp = Column(Integer, nullable=False, index=True)  # Unix timestamp (t)
    pnl = Column(Numeric(20, 8), nullable=False)  # Profit and Loss value (p)
    interval = Column(String(10), nullable=False, default="1m")  # Interval (1m, 5m, etc.)
    fidelity = Column(String(10), nullable=False, default="1d")  # Fidelity (1d, 1w, etc.)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        UniqueConstraint('user_address', 'timestamp', 'interval', 'fidelity', name='uq_user_pnl_unique'),
    )


class UserValue(Base):
    __tablename__ = "user_values"

    id = Column(Integer, primary_key=True, index=True)
    user_address = Column(String(42), nullable=False, unique=True, index=True)  # Wallet address (unique)
    value = Column(Numeric(20, 8), nullable=False)  # User portfolio value
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
