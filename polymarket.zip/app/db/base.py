from app.db.models import Base

__all__ = ["Base"]

