"""User value service for saving and retrieving user portfolio values."""

from typing import Optional, Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from app.db.models import UserValue
from app.services.data_fetcher import fetch_user_value
from decimal import Decimal


async def save_user_value_to_db(
    session: AsyncSession,
    user_address: str,
    value: Decimal
) -> UserValue:
    """
    Save user value to database. Updates existing record or inserts new one.
    
    Args:
        session: Database session
        user_address: Wallet address
        value: Portfolio value
    
    Returns:
        UserValue object
    """
    # Use PostgreSQL upsert (INSERT ... ON CONFLICT DO UPDATE)
    # Conflict on unique user_address
    value_dict = {
        "user_address": user_address,
        "value": value,
    }
    
    stmt = pg_insert(UserValue).values(**value_dict)
    stmt = stmt.on_conflict_do_update(
        index_elements=["user_address"],
        set_={
            "value": stmt.excluded.value,
            "updated_at": stmt.excluded.updated_at,
        }
    )
    
    await session.execute(stmt)
    await session.commit()
    
    # Fetch and return the saved record
    result = await session.execute(
        select(UserValue).where(UserValue.user_address == user_address)
    )
    return result.scalar_one()


async def get_user_value_from_db(
    session: AsyncSession,
    user_address: str
) -> Optional[UserValue]:
    """
    Get user value from database.
    
    Args:
        session: Database session
        user_address: Wallet address
    
    Returns:
        UserValue object or None if not found
    """
    stmt = select(UserValue).where(UserValue.user_address == user_address)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def fetch_and_save_user_value(
    session: AsyncSession,
    user_address: str
) -> tuple[Optional[Dict], Optional[UserValue]]:
    """
    Fetch user value from API and save to database.
    
    Args:
        session: Database session
        user_address: Wallet address
    
    Returns:
        Tuple of (api response dict, saved UserValue object)
    """
    # Fetch user value from API
    value_data = fetch_user_value(user_address)
    
    if not value_data:
        return None, None
    
    # Extract value
    value = Decimal(str(value_data.get("value", 0)))
    
    # Save to database
    saved_value = await save_user_value_to_db(session, user_address, value)
    
    return value_data, saved_value


