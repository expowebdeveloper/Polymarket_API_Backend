"""User value-related schemas."""

from pydantic import BaseModel, Field
from typing import Optional
from decimal import Decimal


class UserValueResponse(BaseModel):
    """Response model for user portfolio value."""
    user: str = Field(..., description="Wallet address", alias="user_address")
    value: Decimal = Field(..., description="Portfolio value")

    class Config:
        json_encoders = {
            Decimal: str
        }
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "user": "0x4fd9856c1cd3b014846c301174ec0b9e93b1a49e",
                "value": "99.284967897"
            }
        }


