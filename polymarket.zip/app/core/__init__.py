"""Core configuration and constants."""

