"""User value API routes."""

from fastapi import APIRouter, HTTPException, Query, status, Depends
from app.schemas.user_value import UserValueResponse
from app.schemas.general import ErrorResponse
from app.services.user_value_service import fetch_and_save_user_value, get_user_value_from_db
from app.db.session import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from decimal import Decimal

router = APIRouter(prefix="/value", tags=["User Value"])


def validate_wallet(wallet_address: str) -> bool:
    """Validate wallet address format."""
    if not wallet_address:
        return False
    if not wallet_address.startswith("0x"):
        return False
    if len(wallet_address) != 42:
        return False
    try:
        int(wallet_address[2:], 16)
        return True
    except:
        return False


@router.get(
    "",
    response_model=UserValueResponse,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid wallet address"},
        404: {"model": ErrorResponse, "description": "User value not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"}
    },
    summary="Fetch and save user value",
    description="Fetch user portfolio value from Polymarket API and save it to the database"
)
async def fetch_and_save_user_value_endpoint(
    user: str = Query(
        ...,
        description="Wallet address to fetch value for (must be 42 characters starting with 0x)",
        example="0x4fd9856c1cd3b014846c301174ec0b9e93b1a49e",
        min_length=42,
        max_length=42
    ),
    db: AsyncSession = Depends(get_db)
):
    """
    Fetch user portfolio value from Polymarket Data API and save it to the database.
    
    This endpoint:
    1. Validates the wallet address format
    2. Fetches user value from https://data-api.polymarket.com/value?user={wallet}
    3. Saves the value to the database (updates if already exists)
    4. Returns the user value
    
    Args:
        user: Wallet address (query parameter)
        db: Database session (injected)
    
    Returns:
        UserValueResponse with user address and portfolio value
    """
    if not validate_wallet(user):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid wallet address format: {user}. Must be 42 characters starting with 0x"
        )
    
    try:
        # Fetch user value from API and save to database
        value_data, saved_value = await fetch_and_save_user_value(db, user)
        
        if not value_data or not saved_value:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User value not found for address: {user}"
            )
        
        return UserValueResponse(
            user_address=user,
            value=saved_value.value
        )
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching and saving user value: {str(e)}"
        )


@router.get(
    "/from-db",
    response_model=UserValueResponse,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid wallet address"},
        404: {"model": ErrorResponse, "description": "User value not found in database"},
        500: {"model": ErrorResponse, "description": "Internal server error"}
    },
    summary="Get user value from database",
    description="Retrieve user portfolio value from the database (without fetching from API)"
)
async def get_user_value_from_db_endpoint(
    user: str = Query(
        ...,
        description="Wallet address to get value for (must be 42 characters starting with 0x)",
        example="0x4fd9856c1cd3b014846c301174ec0b9e93b1a49e",
        min_length=42,
        max_length=42
    ),
    db: AsyncSession = Depends(get_db)
):
    """
    Get user portfolio value from the database.
    
    This endpoint retrieves user value that was previously saved to the database.
    Use the main /value endpoint to fetch fresh data from the API.
    
    Args:
        user: Wallet address (query parameter)
        db: Database session (injected)
    
    Returns:
        UserValueResponse with user address and portfolio value
    """
    if not validate_wallet(user):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid wallet address format: {user}. Must be 42 characters starting with 0x"
        )
    
    try:
        # Get user value from database
        user_value = await get_user_value_from_db(db, user)
        
        if not user_value:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User value not found in database for address: {user}"
            )
        
        return UserValueResponse(
            user_address=user_value.user_address,
            value=user_value.value
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving user value from database: {str(e)}"
        )


