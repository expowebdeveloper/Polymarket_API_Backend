"""
Polymarket Analytics Platform - FastAPI Application
"""

__version__ = "1.0.0"

